HOST = 'localhost'
DATABASE = 'corona_news'
USER = 'your_username'
PASSWORD = 'your_password'